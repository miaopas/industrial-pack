---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Fluix Smithing Template
  icon: fluix_upgrade_smithing_template
  position: 410
categories:
- tools
item_ids:
- ae2:fluix_upgrade_smithing_template
---

<ItemImage id="fluix_upgrade_smithing_template" scale="8" />

# Fluix Smithing Template

Unlike the vanilla smithing template, you can make this one from scratch.

Required for [fluix tools](fluix_tools.md)

## Recipe

<RecipeFor id="fluix_upgrade_smithing_template" />